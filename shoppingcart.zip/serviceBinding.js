function initModel() {
	var sUrl = "/App_odata_v4/OData/cart.xsodata/";
	var oModel = new sap.ui.model.odata.ODataModel(sUrl, true);
	sap.ui.getCore().setModel(oModel);
}