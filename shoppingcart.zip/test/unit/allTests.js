sap.ui.define([
	"test/unit/model/formatter",
	"test/unit/model/EmailType",
	"test/unit/model/LocalStorageModel",
	"test/unit/model/models",
	"test/unit/controller/Checkout.controller"
], function() {
	"use strict";
});